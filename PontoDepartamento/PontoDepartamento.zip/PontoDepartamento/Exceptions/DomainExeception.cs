﻿

namespace PontoDepartamento.Exceptions
{
    class DomainExeception : SystemException
    {
        public DomainExeception(string message) : base(message)
        {

        }
    }
}
